<?php $__env->startSection('title'); ?>
	Bestellen
	<div style="float:right">
		<a class="btn btn-primary" href="<?php echo url('book/create'); ?>">
			Toevoegen...
		</a>
	</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<?php if(count($books) > 0): ?>
		<table class="table table-striped table-hover">
			<thead>
				<th class="col-sm-1">Id</th>
				<th class="col-sm-4">Aantal</th>
				<th class="col-sm-2">Titel</th>
				<th class="col-sm-2">Auteur</th>
				<th class="col-sm-2">Categorie</th>
			</thead>
			<tbody>
				<?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
				<tr class="row-link" style="cursor: pointer;"
					data-href="<?php echo e(action('BookController@show', ['id' => $book->id])); ?>">
					<td class="table-text"><?php echo e($book->id); ?></td>
					<td class="table-text"><?php echo e($book->isbn); ?></td>
					<td class="table-text"><?php echo e($book->title); ?></td>
					<td class="table-text">
						<?php if(isset($book->author)): ?>
						<?php echo e($book->author->name); ?>

						<?php endif; ?>
					</td>
					<td class="table-text">
						<?php if(isset($book->category)): ?>
							<?php echo e($book->category->name); ?>


						<?php endif; ?>
					</td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
			</tbody>
		</table>
	<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
	jQuery(document).ready(function($) {
	    $(".row-link").click(function() {
	        window.document.location = $(this).data("href");
	    });
	    $('#cohort-tabs a:first').tab('show') // Select first tab
	});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>