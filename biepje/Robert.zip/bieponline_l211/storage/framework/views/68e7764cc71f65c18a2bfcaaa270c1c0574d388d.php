<?php $__env->startSection('title'); ?>
<div class="row">
	<div class="col-sm-10">
			(<?php echo e($author->id); ?>) <?php echo e($author->name); ?>

	</div>
	<div class="col-sm-1">
		 <a class="btn btn-default" href="<?php echo e(action('AuthorController@edit', $author->id)); ?>">Bewerken</a>
	</div>
	<div class="col-sm-1">
			<?php echo Form::open(['route' => ['author.destroy', $author->id], 'method'=>'DELETE']); ?>

			<?php echo Form::submit('Verwijderen', array('class'=>'btn btn-danger')); ?>

			<?php echo Form::close(); ?>

	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<table class="table table-striped table-hover">
	<thead>
		<th class="col-sm-1">ID</th>
		<th class="col-sm-4">Naam</th>
	</thead>
	<tbody>
		<tr class="row-link" style="cursor: pointer;"
			data-href="<?php echo e(action('AuthorController@show', ['id' => $author->id])); ?>">
			<td class="table-text"><?php echo e($author->id); ?></td>
			<td class="table-text"><?php echo e($author->name); ?></td>
		</tr>
	</tbody>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>