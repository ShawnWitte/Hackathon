<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<title>BIEPOnline</title>
	<link rel="shortcut icon" href="<?php echo e(asset('favicon.ico')); ?>">
	<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
	<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-T8Gy5hrqNKT+hzMclPo118YTQO6cYprQmhrYwIiQ/3axmI1hQomh7Ud2hPOy8SP1" crossorigin="anonymous">
</head>

<body style="padding-top: 70px;">
<div class="container-fluid">
	<nav class="navbar navbar-inverse  navbar-fixed-top">
		<div class="container-fluid">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>

				<a class="navbar-brand logo" href="<?php echo e(url('/')); ?>"><i class="fa fa-book"></i>&nbspBIEPOnline</a>
			</div>

			<div id="navbar" class="navbar-collapse collapse">
				<ul class="nav navbar-nav">
					<?php echo $__env->yieldContent('ul-navbar-left'); ?>
				</ul>
				<ul class="nav navbar-nav navbar-right">
					<?php echo $__env->yieldContent('ul-navbar-right'); ?>
				</ul>
			</div>
		</div>
	</nav>
	<!-- include the content -->
	<div class="row">
		<div class="col-sm-3 col-md-2 sidebar">
			<div class="nav nav-sidebar">
				<ul class="nav nav-pills nav-stacked">
					<?php echo $__env->make('common.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				</ul>
			</div>
		</div>
		<div class="col-sm-8 col-md-9 main">
			<?php if(array_key_exists('title', View::getSections())): ?>
				<div class="page-header"><h1><?php echo $__env->yieldContent('title', 'title section here'); ?></h1></div>
			<?php endif; ?>
			
			<?php echo $__env->make('common.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<?php echo $__env->make('common.success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

			<?php echo $__env->yieldContent('content'); ?>

		</div>
	</div>
</div>
<?php echo $__env->yieldContent('modals'); ?>
<script   src="https://code.jquery.com/jquery-3.1.1.min.js"   integrity="sha256-hVVnYaiADRTO2PzUGmuLJr8BLUSjGIZsDYGmIJLv2b8="   crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
<!-- include additional scripts -->
<?php echo $__env->yieldContent('scripts'); ?>
</body>
</html>