<?php if(Session::get('success')): ?>
<div class="alert alert-success">
	<button type="button" class="close" data-dismiss="alert"
		aria-label="Close">
		<span aria-hidden="true">&times;</span>
	</button>
	<strong><?php echo e(Session::get('success')); ?></strong>
</div>
<?php endif; ?>
