<?php $__env->startSection('title'); ?>
	Bewerk <?php echo e($user->name); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php echo Form::model($user, ['route' => ['user.update', $user->id], 'method' => 'put', 'class' => 'form-horizontal']); ?>

<div class="form-group">
	<div class="form-group">
		<div class="col-sm-6">
			<?php echo Form::label('name', 'Naam*', ['class' => 'control-label']); ?>

			<?php echo Form::text('name', null, ['class' => 'form-control', 'placeholder' => 'De naam hier']); ?>

		</div>
		<div class="col-sm-6">
			<?php echo Form::label('email', 'Email', ['class' => 'control-label']); ?>

			<?php echo Form::email('email', null, ['class' => 'form-control', 'placeholder' => 'Het e-mailadres hier']); ?>

		</div>
		<div class="col-sm-6">
			<?php echo Form::label('role_id', 'Rol', ['class' => 'control-label']); ?>

			<?php echo Form::select('role_id', $roles, null, ['class' => 'form-control']); ?>

		</div>
		<div class="col-sm-6">
			<?php echo Form::label('location_id', 'Locatie', ['class' => 'control-label']); ?>

			<?php echo Form::select('location_id', $locations, null, ['class' => 'form-control', 'placeholder' => 'Maak een keuze uit de lijst']); ?>

		</div>
	</div>
	<div class="form-group">
		<div class="col-sm-12">
			<button type="submit" class="btn btn-primary">
				Opslaan
			</button>
		</div>
	</div>
<?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>