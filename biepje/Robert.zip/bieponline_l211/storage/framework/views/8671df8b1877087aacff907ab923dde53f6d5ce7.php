<?php $__env->startSection('title'); ?>
	Bestelling Plaatsen
<?php $__env->stopSection(); ?>

<?php $__env->startSection('tools'); ?>
<li role="navigation">
	<a onClick="window.history.back()">
		<i class="fa fa-arrow-left"></i>&nbspTerug
	</a>
</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php echo Form::open(['route' => ['book.store'], 'method' => 'post', 'class' => 'form-horizontal']); ?>

<div class="form-group">
	<div class="col-sm-6">
		<?php echo Form::label('author_id', 'Gereedschap', ['class' => 'control-label']); ?>

		<?php echo Form::select('author_id', $authors, null, ['class' => 'form-control', 'placeholder' => 'Maak een keuze uit de lijst']); ?>

	</div>
	<div class="col-sm-6">
		<?php echo Form::label('category_id', 'Afdeling', ['class' => 'control-label']); ?>

		<?php echo Form::select('category_id', $categories, null, ['class' => 'form-control', 'placeholder' => 'Maak een keuze uit de lijst']); ?>

	</div>
	<div class="col-sm-6">
		<?php echo Form::label('title', 'Naam', ['class' => 'control-label']); ?>

		<?php echo Form::text('title', null, ['class' => 'form-control', 'placeholder' => 'De titel hier']); ?>

	</div>
	<div class="col-sm-6">
		<?php echo Form::label('isbn', 'Bericht', ['class' => 'control-label']); ?>

		<?php echo Form::text('isbn', null, ['class' => 'form-control', 'placeholder' => 'Extra bericht']); ?>

	</div>



</div>

<div class="form-group">
	<div class="col-sm-12">
		<button type="submit" class="btn btn-primary">
			Opslaan
		</button>
	</div>
</div>
<?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>