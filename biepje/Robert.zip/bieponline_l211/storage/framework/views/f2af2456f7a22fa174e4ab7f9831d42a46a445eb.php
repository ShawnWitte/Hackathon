<?php $__env->startSection('title'); ?>
<div class="row">
	<div class="col-sm-10">
			(<?php echo e($user->id); ?>) <?php echo e($user->name); ?>

	</div>
	<div class="col-sm-1">
		 <a class="btn btn-default" href="<?php echo e(action('UserController@edit', $user->id)); ?>">Bewerken</a>
	</div>
	<div class="col-sm-1">
			<?php echo Form::open(['route' => ['user.destroy', $user->id], 'method'=>'DELETE']); ?>

			<?php echo Form::submit('Verwijderen', array('class'=>'btn btn-danger')); ?>

			<?php echo Form::close(); ?>

	</div>
</div>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
<table class="table table-striped table-hover">
	<thead>
		<th class="col-sm-1">ID</th>
		<th class="col-sm-4">Naam</th>
		<th class="col-sm-2">E-mail</th>
		<th class="col-sm-2">Rol</th>
	</thead>
	<tbody>
		<tr class="row-link" style="cursor: pointer;"
			data-href="<?php echo e(action('UserController@show', ['id' => $user->id])); ?>">
			<td class="table-text"><?php echo e($user->id); ?></td>
			<td class="table-text"><?php echo e($user->name); ?></td>
			<td class="table-text"><?php echo e($user->email); ?></td>
				<?php if(!empty($user->role->name)): ?>
			<td class="table-text"><?php echo e($user->role->name); ?></td>
				<?php endif; ?>
		</tr>
	</tbody>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>