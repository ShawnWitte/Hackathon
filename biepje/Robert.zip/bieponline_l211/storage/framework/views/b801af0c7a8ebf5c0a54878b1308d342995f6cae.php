<?php $__env->startSection('title'); ?>
	Nieuwe rol toevoegen
<?php $__env->stopSection(); ?>

<?php $__env->startSection('tools'); ?>
<li role="navigation">
	<a onClick="window.history.back()">
		<i class="fa fa-arrow-left"></i>&nbspTerug
	</a>
</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php echo Form::open(['route' => ['role.store'], 'method' => 'post', 'class' => 'form-horizontal']); ?>

<div class="form-group">
	<div class="col-sm-12">
		<?php echo Form::label('name', 'Naam*', ['class' => 'control-label']); ?>

		<?php echo Form::text('name', null, ['class' => 'form-control', 'placeholder' => 'De naam hier']); ?>

	</div>
</div>

<div class="form-group">
	<div class="col-sm-12">
		<button type="submit" class="btn btn-primary">
			Opslaan
		</button>
	</div>
</div>
<?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>