<?php $__env->startSection('title'); ?>
	Bewerk <?php echo e($author->name); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php echo Form::model($author, ['route' => ['author.update', $author->id], 'method' => 'put', 'class' => 'form-horizontal']); ?>

<div class="form-group">
	<div class="form-group">
		<div class="col-sm-6">
			<?php echo Form::label('name', 'Naam*', ['class' => 'control-label']); ?>

			<?php echo Form::text('name', null, ['class' => 'form-control', 'placeholder' => 'De naam hier']); ?>

		</div>
	</div>
	<div class="form-group">
		<div class="col-sm-12">
			<button type="submit" class="btn btn-primary">
				Opslaan
			</button>
		</div>
	</div>
<?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>